# 从安装到第一条口播稿

[返回介绍](../README.md) · [语料与校准](samples-and-calibration.md) · [完整演示](examples.md)

## 1. 选择安装入口

Windows和macOS共用本包。**WorkBuddy**直接上传ZIP；**Codex**安装解压后的完整文件夹。下面分开说明，详见[平台适配与验证范围](platforms.md)。

### WorkBuddy

下载下面的独立ZIP，在「专家·技能·连接器 → 技能 → 添加技能 → 上传技能」中选择它，再到「已安装」确认启用。新建任务时选好存放作者资料的工作目录。该入口依据[WorkBuddy官方技能说明](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)，尚未在真实WorkBuddy客户端导入实测。

### Codex

[下载单项 ZIP](https://github.com/hanxu66/hanxu-user-skills/raw/main/packages/hanxu-script-agent.zip)，解压后保留整个 `hanxu-script-agent` 文件夹。里面应有 `SKILL.md`、`README.md`、`references/`、`scripts/`、`agents/`、`docs/` 和 `SOURCE.json`。

可以把文件夹交给 Codex，说：

```text
请检查这个 Skill 的内容和依赖，将完整的 hanxu-script-agent 文件夹安装到适合我的本地 Skill 目录。不要覆盖已有的个人资料或改动其他 Skill；如果已有同名版本，先比较并保留我的修改。
```

手动安装可选择以下一个位置：

| 使用范围 | 文件应在的位置 |
| --- | --- |
| 当前用户的各个项目 | `~/.agents/skills/hanxu-script-agent/SKILL.md` |
| 某个项目内使用 | `项目目录/.agents/skills/hanxu-script-agent/SKILL.md` |

不要把 ZIP 原封不动放进目录，也不要形成两层 `hanxu-script-agent/hanxu-script-agent/`。同名 Skill 放在多个位置可能重复出现，更新时先确认正在使用哪份。Codex 会自动发现本地 Skill 变化；没有出现时再重启。目录与发现方式依据 [OpenAI 官方 Skill 文档](https://learn.chatgpt.com/docs/build-skills)。

## 2. 带着一条具体题目开始

在你的内容项目中输入以下文本，替换括号中的内容：

示例第一行用于Codex对话。WorkBuddy把第一行替换为“请使用已安装的短视频口播文风助手（hanxu-script-agent）”；后续写稿、改稿和新题接续相同。无需在系统终端执行这段文字。

```text
$hanxu-script-agent
我想讲【这次的题目】，给【具体观众】听。
我目前的想法是：【按自己的话说】。
理由或材料：【经历、观察、原文、可以核对的来源】。
请理清论点与论证、安排结构，写成完整口播稿。
有本人样本就学习，没有就通过这次对话和改稿逐步校准。
```

知道时长、平台或公开边界时可以一并说明；不知道时不必先填一份配置表。只给题目、还没想清观点时，可以直接说“先帮我把想法问清楚”。缺少事实依据时应补材料或缩小主张，不用风格润色补造经历。

有语料就追加：“下面是我自己说过或亲手改过的内容，请学表达，不把旧事实搬进新稿。”没有语料可以追加：“我没有历史样本，已有材料够用就先写，不要等我整理语料库。”

## 3. 看完整作品，再改具体一句

第一轮应给出完整稿，并简要说明核心判断、论据为何能支撑它、结构安排和口吻处理；个人表达仍待本人确认。你只想看稿，可以要求“前台只交正文，其他依据放任务文件”。

返修可以直接给本人说法：

```text
这句“【原句】”我不会这么说，我会说“【我的说法】”。
这次只改口吻，保留事实、论点、论证和结构。
【如果确实适用于以后再加：这是我的长期偏好。】
```

若核心意思不对，应说“我真正想表达的是……”，允许回到论点和论证处理。局部返修与改观点的影响范围不同，不用把所有问题都归为文风。

## 4. 第二条继续用自己的记录

默认在当前项目的 `口播试用/` 保存 `作者表达记录.md` 和各题稿件，也可以指定目录。多位作者分开保存，个人资料放在内容项目中，方便升级 Skill 时保留。

```text
$hanxu-script-agent
继续使用【作者表达记录所在目录】里的我的表达记录。
这次新题是【题目】，新材料是【材料】。
只继承适用的表达偏好，旧题的事实和观点不要自动带过来。
```

换聊天、项目或机器时，需要仍能访问这些文件，或者把记录带到新环境；安装 Skill 本身不提供资料同步或跨账号记忆。

## 更新与版本

产品试用版为 **v0.1.1**，保留v0.1写稿方法并增加Windows/WorkBuddy适配；每次安装包的构建版本见 [SOURCE.json](../SOURCE.json)，仓库首页显示分享合集版本。

更新前保留你对安装文件的本地修改及作者资料，下载后比较同名文件夹再更新。旧安装标识仍是 `$hanxu-script-agent`，展示名为“短视频口播文风助手”。

安装或调用遇到问题，见 [常见问题](faq.md)；想反馈试用情况，见 [试用与反馈](trial-and-feedback.md)。
